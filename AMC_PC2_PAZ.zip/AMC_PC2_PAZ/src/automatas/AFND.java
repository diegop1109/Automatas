/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package automatas;

import java.util.ArrayList;
import transiciones.Lambda;
import transiciones.TransicionAFND;

/**
 *
 * @author diepa
 */
public class AFND implements Proceso {

    //componentes
    private ArrayList<Integer> estadosFinales; //indica cuales son los estados finales
    private ArrayList<TransicionAFND> transiciones; //lista de transiciones
    private ArrayList<Lambda> transicionesLambda; //lista de transiciones lambda
    private Integer estadoInicial;
    private ArrayList<Integer> listaEstados;
    private ArrayList<Object> alfabeto;

    //auxiliar
    int nEstados;

    public AFND() {
        this.estadosFinales = new ArrayList();
        this.transiciones = new ArrayList();
        this.transicionesLambda = new ArrayList();
        this.estadoInicial = 0;
        this.listaEstados = new ArrayList();
        this.alfabeto = new ArrayList();
    }

    public ArrayList<Integer> getEstadosFinales() {
        return estadosFinales;
    }

    public void setEstadosFinales(ArrayList<Integer> estadosFinales) {
        this.estadosFinales = estadosFinales;
    }

    public ArrayList<TransicionAFND> getTransiciones() {
        return transiciones;
    }

    public void setTransiciones(ArrayList<TransicionAFND> transiciones) {
        this.transiciones = transiciones;
    }

    public ArrayList<Lambda> getTransicionesLambda() {
        return transicionesLambda;
    }

    public void setTransicionesLambda(ArrayList<Lambda> transicionesLambda) {
        this.transicionesLambda = transicionesLambda;
    }

    public Integer getEstadoInicial() {
        return estadoInicial;
    }

    public void setEstadoInicial(Integer estadoInicial) {
        this.estadoInicial = estadoInicial;
    }

    public ArrayList<Integer> getListaEstados() {
        return listaEstados;
    }

    public void setListaEstados(ArrayList<Integer> listaEstados) {
        this.listaEstados = listaEstados;
    }

    public ArrayList<Object> getAlfabeto() {
        return alfabeto;
    }

    public void setAlfabeto(ArrayList<Object> alfabeto) {
        this.alfabeto = alfabeto;
    }

    public int getnEstados() {
        return nEstados;
    }

    public void setnEstados(int nEstados) {
        this.nEstados = nEstados;
    }

    private ArrayList<Integer> lambda_clausura(int estado, ArrayList<Integer> lista) {
        ArrayList<Integer> resultados = new ArrayList();
        resultados.add(estado);
        if (!lista.contains(estado)) {
            for (int i = 0; i < transicionesLambda.size(); i++) {
                if (transicionesLambda.get(i).getOrigen() == estado && !lista.contains(estado)) {
                    lista.add(estado);
                    for (int j = 0; j < transicionesLambda.get(i).getDestinos().size(); j++) {
                        if (!lista.contains(transicionesLambda.get(i).getDestinos().get(j))) {
                            resultados.addAll(lambda_clausura(transicionesLambda.get(i).getDestinos().get(j), lista));

                        }
                    }
                }
            }
            //Si no existe ninguna transicion Lambda con origen en "estado",
            if (!lista.contains(estado)) {
                lista.add(estado);
            }
        } else {
            resultados.clear();
        }
        return resultados;
    }

    @Override
    public void cargarFichero(String archivo) throws Exception {

    }

    @Override
    public boolean esFinal(int estado) {
        return this.estadosFinales.contains(estado);
    }

    public boolean esFinal2(ArrayList<Integer> macroEstado) {
        macroEstado.retainAll(estadosFinales);
        return macroEstado.isEmpty();
    }

    @Override
    public boolean reconocer(String cadena) {
        char[] caracter = cadena.toCharArray();
        ArrayList<Integer> macroEstado = new ArrayList();
        ArrayList<Integer> inicio = new ArrayList();
        ArrayList<Integer> lista = new ArrayList();

        for (int i = 0; i < inicio.size(); i++) {
            macroEstado = lambda_clausura(inicio.get(i), lista);
        }

        for (int i = 0; i < caracter.length; i++) {
            macroEstado = Transicion(inicio, caracter[i]);
        }
        return esFinal2(macroEstado);
    }

    public void agregarTransicion(int origen, ArrayList<Integer> destino, Object simbolo) {
        transiciones.add(new TransicionAFND(origen, destino, simbolo));
    }

    public void agregarEstado(int nuevoEstado) {
        listaEstados.add(nuevoEstado);
    }

    public void agregarSimbolo(Object nuevoSimbolo) {
        if (!alfabeto.contains(nuevoSimbolo)) {
            alfabeto.add(nuevoSimbolo);
        }
    }

    public void agregarEstadoFinal(int nuevoEstado) {
        estadosFinales.add(nuevoEstado);
    }

    public void agregarTransicionLambda(int origen, ArrayList<Integer> destinos) {
        transicionesLambda.add(new Lambda(origen, destinos));
    }

    private ArrayList<Integer> Transicion(int estado, char simbolo) {
        ArrayList<Integer> nuevo = new ArrayList();

        for (int i = 0; i < transiciones.size(); i++) {
            if ((transiciones.get(i).getOrigen() == estado)
                    && (transiciones.get(i).getSimbolo().equals(simbolo))) {
                nuevo = transiciones.get(i).getDestinos();
            }
        }
        return nuevo;
    }

    public ArrayList<Integer> Transicion(ArrayList<Integer> macroEstado, char simbolo) {
        ArrayList<Integer> nuevo = new ArrayList();
        for (int i = 0; i < transiciones.size(); i++) {
            if ((transiciones.get(i).getDestinos() == macroEstado)
                    && (transiciones.get(i).getSimbolo().equals(simbolo))) {
                nuevo.add(transiciones.get(i).getOrigen());
            }
        }
        return nuevo;
    }

    public ArrayList<Integer> TransicionLambda(int estado) {
        ArrayList<Integer> nuevoL = new ArrayList();
        for (int i = 0; i < transicionesLambda.size(); i++) {
            if (transicionesLambda.get(i).getOrigen() == estado) {
                nuevoL = transiciones.get(i).getDestinos();
            }
        }
        return nuevoL;
    }

}
