/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package automatas;

import java.util.ArrayList;
import java.util.Scanner;
import transiciones.TransicionAFD;

/**
 *
 * @author diepa
 */
public class AFD implements Proceso {

    //componentes que conforman un automata finito
    ArrayList<Integer> listaEstados;    //conjunto de estados definidos
    ArrayList<Object> alfabeto; //conjunto de simbolos
    ArrayList<TransicionAFD> transiciones;  //conjunto de transiciones
    Integer estadoInicial;  //estado inicial
    ArrayList<Integer> estadosFinales;  //estados finales definidos

    //auxiliares
    int nEstados; //indica numero de estados del alfabeto

    public AFD() {
        this.listaEstados = new ArrayList();
        this.alfabeto = new ArrayList();
        this.transiciones = new ArrayList();
        this.estadoInicial = 0;
        this.estadosFinales = new ArrayList();
    }

    public void agregarTransicion(int origen, int destino, Object simbolo) {
        transiciones.add(new TransicionAFD(origen, destino, simbolo));
    }

    public int Transicion(char caracter, int inicio) {
        int resultado = 0;
        for (int i = 0; i < transiciones.size(); i++) {
            if ((transiciones.get(i).getOrigen() == inicio)
                    && (transiciones.get(i).getSimbolo().equals(caracter))) {
                resultado = transiciones.get(i).getDestino();
            }
        }
        return resultado;
    }

    public void agregarEstado(int nuevoEstado) {
        listaEstados.add(nuevoEstado);
    }
    
    public void agregarSimbolo(Object nuevoSimbolo) {
        if (!alfabeto.contains(nuevoSimbolo)) alfabeto.add(nuevoSimbolo);
    }
    
    public void agregarEstadoFinal(int nuevoEstado) {
        estadosFinales.add(nuevoEstado);
    }

    public ArrayList<Integer> getListaEstados() {
        return listaEstados;
    }

    public void setListaEstados(ArrayList<Integer> listaEstados) {
        this.listaEstados = listaEstados;
    }

    public int getnEstados() {
        return nEstados;
    }

    public void setnEstados(int nEstados) {
        this.nEstados = nEstados;
    }
    
    public ArrayList<Object> getAlfabeto() {
        return alfabeto;
    }

    public void setAlfabeto(ArrayList<Object> alfabeto) {
        this.alfabeto = alfabeto;
    }

    public ArrayList<TransicionAFD> getTransiciones() {
        return transiciones;
    }

    public void setTransiciones(ArrayList<TransicionAFD> transiciones) {
        this.transiciones = transiciones;
    }

    public Integer getEstadoInicial() {
        return estadoInicial;
    }

    public void setEstadoInicial(Integer estadoInicial) {
        this.estadoInicial = estadoInicial;
    }

    public ArrayList<Integer> getEstadosFinales() {
        return estadosFinales;
    }

    public void setEstadosFinales(ArrayList<Integer> estadosFinales) {
        this.estadosFinales = estadosFinales;
    }

    @Override
    public void cargarFichero(String archivo) throws Exception {
        
    }

    @Override
    public boolean esFinal(int estado) {
        return this.estadosFinales.contains(estado);
    }

    @Override
    public boolean reconocer(String cadena) {
        char[] caracter = cadena.toCharArray();
        int inicio = 0;

        for (int i = 0; i < caracter.length; i++) {
            inicio = Transicion(caracter[i], inicio);
        }
        return esFinal(inicio);
    }

    public static AFD pedir() {
        AFD auto = new AFD();
        Scanner lectura = new Scanner(System.in);

        System.out.println("Desea: ");
        System.out.println("1. Teclear el alfabeto");
        System.out.println("2. Adjuntar un fichero");
        System.out.print("respuesta(solo el numero): ");
        String opcion = lectura.nextLine();
        System.out.println("");

        if (opcion.equals("1")) {
            System.out.println("Ingresar alfabeto por teclado (separar por comas)... ");
            String Input = lectura.nextLine();

            String[] nuevoAlfabeto = Input.split(",");
            for (String n : nuevoAlfabeto) {
                auto.alfabeto.add(n);
            }
        } else {
            System.out.println("Ingresar nombre del fichero...");
            String fichero = lectura.nextLine();
            
            try {
                auto.cargarFichero(fichero);
            } catch (Exception e) {
                System.out.println("error al cargar fichero");
            }
        }
        return auto;
    }
}
