/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transiciones;

/**
 *
 * @author diepa
 */
public class TransicionAFD {
    int origen;
    int destino;
    Object simbolo;

    public TransicionAFD(int origen, int destino, Object simbolo) {
        this.origen = origen;
        this.destino = destino;
        this.simbolo = simbolo;
    }

    public int getOrigen() {
        return origen;
    }

    public void setOrigen(int origen) {
        this.origen = origen;
    }

    public int getDestino() {
        return destino;
    }

    public void setDestino(int destino) {
        this.destino = destino;
    }

    public Object getSimbolo() {
        return simbolo;
    }

    public void setSimbolo(Object simbolo) {
        this.simbolo = simbolo;
    }
    
}
