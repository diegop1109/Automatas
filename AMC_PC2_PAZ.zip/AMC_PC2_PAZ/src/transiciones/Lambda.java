/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transiciones;

import java.util.ArrayList;

/**
 *
 * @author diepa
 */
public class Lambda {
    int origen;
    ArrayList<Integer> destinos;

    public Lambda(int origen, ArrayList<Integer> destinos) {
        this.origen = origen;
        this.destinos = destinos;
    }

    public int getOrigen() {
        return origen;
    }

    public ArrayList<Integer> getDestinos() {
        return destinos;
    }
}
