/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transiciones;

import java.util.ArrayList;

/**
 *
 * @author diepa
 */
public class TransicionAFND {
    int origen;
    ArrayList<Integer> destinos;
    Object simbolo;

    public TransicionAFND(int origen, ArrayList<Integer> destino, Object simbolo) {
        this.origen = origen;
        this.destinos = destino;
        this.simbolo = simbolo;
    }

    public int getOrigen() {
        return origen;
    }

    public void setOrigen(int origen) {
        this.origen = origen;
    }

    public ArrayList<Integer> getDestinos() {
        return destinos;
    }

    public void setDestinos(ArrayList<Integer> destinos) {
        this.destinos = destinos;
    }

    public Object getSimbolo() {
        return simbolo;
    }

    public void setSimbolo(Object simbolo) {
        this.simbolo = simbolo;
    }
}
